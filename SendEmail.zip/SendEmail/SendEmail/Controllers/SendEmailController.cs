﻿using Microsoft.AspNetCore.Mvc;
using SendEmail.DataModel.Entities;
using SendEmail.Services.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace SendEmail.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SendEmailController : ControllerBase
    {
        private readonly IEmployeServices _employeServices;
        public SendEmailController(IEmployeServices employeServices)
        {
            _employeServices = employeServices;

        }
        // GET api/<LOPController>
        [HttpGet]
        public async Task<IEnumerable<EmployeePayrollStatus>> Get()
        {

            var message = await _employeServices.GetAllEmployee();
            return message;

        }

    }
}
