﻿using SendEmail.DataModel.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SendEmail.Services.Interfaces
{
    public interface IEmployeServices
    {
        Task<IEnumerable<EmployeePayrollStatus>> GetAllEmployee();
    }
}
