﻿namespace SendEmail.DataModel.Entities
{
    public class EmployeePayrollStatus
    {
        public int employeeId { get; set; }
        public string employeeeName { get; set; }
        public string employeeEmail { get; set; }
        public int presentDays { get; set; }
        public int lossOfPay { get; set; }
        public int leavesTaken { get; set; }
    }
}
