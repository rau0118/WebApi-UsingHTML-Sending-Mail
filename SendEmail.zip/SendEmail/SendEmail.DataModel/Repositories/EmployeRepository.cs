﻿using Grpc.Core;
using Microsoft.Extensions.Configuration;
using SendEmail.DataModel.Entities;
using SendEmail.DataModel.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;
using System.Threading.Tasks;
namespace SendEmail.DataModel.Repositories
{
    public class EmployeRepository : IEmployeRepository
    {
        public IConfiguration Configuration { get; }
        public string connectionString;

        public EmployeRepository(IConfiguration configuration)
        {
            Configuration = configuration;
            connectionString = Configuration["ConnectionStrings:DefaultConnection"];

        }
        private AlternateView Mail_Body()
        {
            string path = @"C:\Users\raushan.kumar\Desktop\SendEmail\SendEmail\\Template\925816220s-removebg-preview.png";
            LinkedResource Img = new LinkedResource(path, MediaTypeNames.Image.Jpeg);
            Img.ContentId = "MyImage";
            string path1 = @"C:\Users\raushan.kumar\Desktop\SendEmail\SendEmail\Template\TemplateOfEmail.html";

            string textBox = File.ReadAllText(path1);

            string TextBox = Convert.ToString(textBox.ToString());
            AlternateView AV =
            AlternateView.CreateAlternateViewFromString(TextBox, null, MediaTypeNames.Text.Html);
            AV.LinkedResources.Add(Img);
            return AV;
        }


        public async Task<IEnumerable<EmployeePayrollStatus>> GetAllEmployee()
        {

            List<EmployeePayrollStatus> ep = new List<EmployeePayrollStatus>();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string qurr = "select * from EmployeePayrollStatus";
                    SqlCommand cmmd = new SqlCommand(qurr, con);
                    SqlDataReader reader = cmmd.ExecuteReader();
                    while (reader.Read())
                    {
                        EmployeePayrollStatus emps = new EmployeePayrollStatus();
                        emps.employeeId = Convert.ToInt32(reader["employeeId"]);
                        emps.employeeeName = reader["employeeeName"].ToString();
                        emps.employeeEmail = reader["employeeEmail"].ToString();
                        emps.presentDays = Convert.ToInt32(reader["presentDays"]);
                        emps.lossOfPay = Convert.ToInt32(reader["lossOfPay"]);
                        emps.leavesTaken = Convert.ToInt32(reader["leavesTaken"]);
                        ep.Add(emps);
                    }

                    foreach (var emp in ep)
                    {

                       
                        try
                        {

                            MailMessage mail = new MailMessage();
                            SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
                            mail.From = new MailAddress("tommy121tom@gmail.com");
                            mail.To.Add(emp.employeeEmail);
                            mail.Subject = "EmployeeLop";
                           // mail.Body = TextBox;
                            mail.IsBodyHtml = true;
                            mail.AlternateViews.Add(Mail_Body());
                            SmtpServer.Port = 587;
                            SmtpServer.Credentials = new System.Net.NetworkCredential("tommy121tom@gmail.com", "Star@123");
                            SmtpServer.EnableSsl = true;
                            SmtpServer.Send(mail);

                        }
                        catch (Exception e)
                        {

                            Console.WriteLine(e);
                        }
                    }

                    reader.Close();
                    con.Close();
                }
                catch (Exception ex)
                {

                    string ex1 = "error in fetching data";
                    ex1 = ex.Message;
                }

            }
            var message = await Task.FromResult(ep);
            return message;
        }
    }
}
