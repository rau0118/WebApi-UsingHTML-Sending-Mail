﻿namespace SendEmail.DataModel.Entities
{
    public class EmployeePayroll
    {
        public int employeeId { get; set; }
        public string employeeName { get; set; }
        public string Email { get; set; }
        public int PresentDays { get; set; }
        public int Leaves { get; set; }
        public int LOP { get; set; }

    }
}
