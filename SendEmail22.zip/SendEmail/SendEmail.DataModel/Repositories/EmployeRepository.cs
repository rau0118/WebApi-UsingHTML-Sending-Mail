﻿using Microsoft.Extensions.Configuration;
using SendEmail.DataModel.Entities;
using SendEmail.DataModel.Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Net.Mail;
using System.Net.Mime;
using System.Threading.Tasks;

namespace SendEmail.DataModel.Repositories
{
    public class EmployeRepository : IEmployeRepository
    {
        public List<EmployeePayrollStatus> ep = new List<EmployeePayrollStatus>();
        public IConfiguration Configuration { get; }
        public string connectionString;
        public int Raushanid;
        public string RaushanName = "";
        public int RaushanPresent;
        public int RaushanLeaves;
        public int RaushanLOP;
        public string RaushanEmail;




        public EmployeRepository(IConfiguration configuration)
        {
            Configuration = configuration;
            connectionString = Configuration["ConnectionStrings:DefaultConnection"];

        }
        public EmployeRepository()
        {

        }
        private AlternateView Mail_Body(int id, string name, int Present, int Leaves, int LOP,string email)
        {
            string eid = Convert.ToString(id);
            string pre = Convert.ToString(Present);
            string leav = Convert.ToString(Leaves);
            string elop = Convert.ToString(LOP);
            string path = @"C:\Users\raushan.kumar\Desktop\SendEmail\SendEmail\Template\925816220s-removebg-preview.png";
            LinkedResource Img = new LinkedResource(path, MediaTypeNames.Image.Jpeg);
            Img.ContentId = "MyImage";
            string path1 = @"C:\Users\raushan.kumar\Desktop\SendEmail\SendEmail\Template\Eamilpage.html";

            string textBox = File.ReadAllText(path1);
            textBox = textBox.Replace("{employeeId}", eid);
            textBox = textBox.Replace("{employeeName}", name);
            textBox = textBox.Replace("{Present}", pre);
            textBox = textBox.Replace("{Leaves}", leav);
            textBox = textBox.Replace("{LOP}", elop);
            textBox = textBox.Replace("{eamil}", email);

            string TextBox = Convert.ToString(textBox.ToString());
            AlternateView AV =
            AlternateView.CreateAlternateViewFromString(TextBox, null, MediaTypeNames.Text.Html);
            AV.LinkedResources.Add(Img);
            return AV;
        }
        public async Task<IEnumerable<EmployeePayrollStatus>> GetAllEmployee()
        {

            //List<EmployeePayrollStatus> ep = new List<EmployeePayrollStatus>();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string qurr = "select * from EmployeePayrollStatus";
                    SqlCommand cmmd = new SqlCommand(qurr, con);
                    SqlDataReader reader = cmmd.ExecuteReader();
                    while (reader.Read())
                    {
                        EmployeePayrollStatus emps = new EmployeePayrollStatus();
                        emps.employeeId = Convert.ToInt32(reader["employeeId"]);
                        emps.employeeeName = reader["employeeeName"].ToString();
                        emps.employeeEmail = reader["employeeEmail"].ToString();
                        emps.presentDays = Convert.ToInt32(reader["presentDays"]);
                        emps.leavesTaken = Convert.ToInt32(reader["leavesTaken"]);
                        emps.lossOfPay = Convert.ToInt32(reader["lossOfPay"]);
                        ep.Add(emps);
                    }

                    foreach (var emp in ep)
                    {
                        RaushanEmail = emp.employeeEmail;
                        Raushanid = emp.employeeId;
                        RaushanName = emp.employeeeName;
                        RaushanPresent = emp.presentDays;
                        RaushanLeaves = emp.leavesTaken;
                        RaushanLOP = emp.lossOfPay;
                        try
                        {

                            MailMessage mail = new MailMessage();
                            SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");
                            mail.From = new MailAddress("tommy121tom@gmail.com");
                            //mail.To.Add(emp.Email);
                            mail.To.Add("raushan.kumar@starmarkit.com");
                            mail.To.Add("dharnish.r@starmarkit.com");
                           // mail.To.Add("mayura.sonar@starmarkit.com");
                            mail.To.Add("raushan.raj0118@gmail.com");

                            mail.Subject = "EmployeeLop";
                            mail.IsBodyHtml = true;
                            var emailOutput = Mail_Body(Raushanid, RaushanName, RaushanPresent, RaushanLeaves, RaushanLOP, RaushanEmail);
                            mail.AlternateViews.Add(emailOutput);
                            SmtpServer.Port = 587;
                            SmtpServer.Credentials = new System.Net.NetworkCredential("tommy121tom@gmail.com", "Star@123");
                            SmtpServer.EnableSsl = true;
                            SmtpServer.Send(mail);
                            //var viewPath = Path.Combine("template", "emp.cshtml");

                            //var template = File.ReadAllText(viewPath);

                            //var model = new EmployeePayroll
                            //{
                            //    employeeId = Raushanid,
                            //    employeeName = RaushanName,
                            //    PresentDays = RaushanPresent,
                            //    Leaves = RaushanLeaves,
                            //    LOP = RaushanLOP,
                            //};
                            //var email = new Email<EmployeePayroll>(template, model);
                            //var task =
                            //    email.SendAsync(new[] { "raushan.raj0118@gmail.com" }
                            //                                 , "subject");

                            //task.Wait();


                        }
                        catch (Exception e)
                        {

                            Console.WriteLine(e);
                        }
                    }

                    reader.Close();
                    con.Close();
                }
                catch (Exception ex)
                {

                    string ex1 = "error in fetching data";
                    ex1 = ex.Message;
                }

            }
            var message = await Task.FromResult(ep);
            return message;
        }
    }
}
