﻿using SendEmail.DataModel.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SendEmail.DataModel.Repositories.Interfaces
{
    public interface IEmployeRepository
    {
        Task<IEnumerable<EmployeePayrollStatus>> GetAllEmployee();
        
    }
}
