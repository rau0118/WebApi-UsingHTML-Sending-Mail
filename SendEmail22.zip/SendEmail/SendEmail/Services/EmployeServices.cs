﻿using SendEmail.DataModel.Entities;
using SendEmail.DataModel.Repositories.Interfaces;
using SendEmail.Services.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SendEmail.Services
{
    public class EmployeServices:IEmployeServices
    {
        private readonly IEmployeRepository _employeRepository;
        public EmployeServices(IEmployeRepository employeRepository)
        {
            _employeRepository = employeRepository;
        }
        public async Task<IEnumerable<EmployeePayrollStatus>> GetAllEmployee()
        {
            var message = await _employeRepository.GetAllEmployee();
            return message;
        }
    }
}
