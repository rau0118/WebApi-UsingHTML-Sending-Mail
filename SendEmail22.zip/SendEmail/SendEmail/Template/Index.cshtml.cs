using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SendEmail.Template
{
    public class IndexModel : PageModel
    {

        public void OnGet()
        {
        }
    }
}
