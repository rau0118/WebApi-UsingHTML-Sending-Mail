SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AttendanceData](
	[EmpId] [varchar](10) NOT NULL,
	[EmpName] [varchar](100) ,
	[ReportingOfficer] [varchar](100) ,
	[RevOfficer] [varchar](100) ,
	[Leave] [varchar](50),
	[Present] [varchar](100),
	[LOPCount] [varchar](100),
	[BranchCode] [nchar](10),
	[Designation] [varchar](100),
	[Division] [varchar](100))
PRIMARY KEY CLUSTERED 
(
	[EmpId] ASC,
	[Date] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

Select * from  [dbo].[AttendanceData]

Drop table AttendanceData