﻿using DemoMVCtoSend_Mail.model;
using Microsoft.EntityFrameworkCore;

namespace DemoMVCtoSend_Mail.DataCenter
{
    class ApplicationDbCenter : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Data Source=AA161217-BLR\\SQLEXPRESS;Initial Catalog=LOPManagement;Integrated Security=True");
        }
        public DbSet<Employee> Employee { get; set; }


    }

}
